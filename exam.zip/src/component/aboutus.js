import React from 'react'

export default function AboutUs1(){
    return(
        <>
        <h1>aboutus</h1>
        </>
    )
}