import React from 'react'

export default function Home1(){
    return(
        <>
        <h1>home</h1>
        </>
    )
}