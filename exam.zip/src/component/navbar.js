import React from 'react'
import {Nav,Navbar,Container,Row,Col} from 'react-bootstrap'
import {Link} from 'react-router-dom'


export default function Navbar1(){

    return(
    <>
  <Navbar bg="dark" variant="dark">
  <Container>
    <Navbar.Brand>Navbar</Navbar.Brand>
    <Nav className="ml-auto">
      <Nav.Link ><Link to="/data1">Data</Link></Nav.Link>
      <Nav.Link><Link to="/home">Home</Link></Nav.Link>
      <Nav.Link><Link to="/aboutus">About Us</Link></Nav.Link>
      <Nav.Link><Link to="/onlineappoinment">Online Appoinment</Link></Nav.Link>
      <Nav.Link><Link to="/login">Login</Link></Nav.Link>
      <Nav.Link><Link to="/register">Register</Link></Nav.Link>
      <Nav.Link>Contact Us</Nav.Link>
    </Nav>
    </Container>
  </Navbar>
  
    </>
    )
}