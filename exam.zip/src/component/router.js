import React from 'react'
import { Route, Switch, BrowserRouter as Router } from 'react-router-dom'
import Navbar1 from '../component/navbar'
import Home1 from './home'
import AboutUs1 from './aboutus'
import OnlineAppoinment1 from './onlineappoinment'
import Login1 from './login'
import Register1 from './register'
import ProtectedRoute from './protectedrout'
import Data1 from './data'



export default function Router1(){

    return(
        <>
        <Router>
            <Navbar1></Navbar1>
            
            <Route>
                <Switch>
                    <Route exact path="/home" component={Home1}/>
                    <Route exact path="/aboutus" component={AboutUs1}/>
                    <Route exact path="/onlineappoinment" component={OnlineAppoinment1}/>
                    <Route exact path="/login" component={Login1}/>
                    <Route exact path="/register" component={Register1}/>
                    <ProtectedRoute path="/data" component={Data1}/>
                </Switch>
            </Route>
        </Router>
        </>
    )
} 