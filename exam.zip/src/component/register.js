import React,{useState}from 'react'
import { Container,Form,Button,Col,Row } from 'react-bootstrap'
import axios from 'axios';



const Register1=()=>{

    const backgroundstyle={
      backgroundColor: "lightBlue",  
    padding: "10px",  
    fontFamily: "Arial" ,
    width:"550px",
    marginTop:"15px"
    }
    const p={
      color: "red",
       paddingLeft: "15px",
       marginBottom:"0px"
   }

    const [valid,setValid] = useState({firstname:"",lastname:"",email:"",password:"",butt:true,error:{firstname:"*",lastname:"*",email:"*",password:"*"}})

    const handleChange=(e)=>{
        // console.log(e);
        // console.log(e.target.value);
        const {name,value}=e.target;
        const isValid = {...valid};
        const fnameValidity=RegExp(/^([a-zA-Z]{5,})+$/i)
        const lnameValidity=RegExp(/^([a-zA-Z]{5,})+$/i)
        const emailValidity=RegExp(/^[A-Z0-9._%+-]+@([A-Z0-9-]+\.)+[A-Z]{2,4}$/i)
        // const passwordValidity=RegExp(/^w+[+.w-]*@([w-]+.)*w+[w-]*.([a-z]{2,4}|d+)$/i)


        switch (name) {
            case "firstname":
                isValid.error.firstname= fnameValidity.test(value) ? "" : "* minimum 8 Character";
                isValid.firstname=value;
                // setName(value);
                break;
            case "lastname":
                isValid.error.lastname= lnameValidity.test(value) ? "" : "* minimum 8 Character";
                isValid.lastname=value;
                // setName(value);
                break;
            case "email":
                isValid.error.email= emailValidity.test(value) ? "" : "* Not Valid";
                isValid.email=value;
                // setEmail(value)
                break;
            case "password":
                isValid.error.password= value.length <5 ? "* minnimum 6" : "";
                isValid.password=value;
                // setpassword(value)
                break;
        
            default:
                break;
        }

        if((isValid.error.firstname === "") && (isValid.error.lastname === "") && (isValid.error.email === "") && (isValid.error.password === ""))
        {
            isValid.butt=false;
            // setButt(false);
        }
        else
        {
            isValid.butt=true;
            // setButt(true);
        }

        console.log(isValid);
        console.log(valid);

        // setError(isValid.error)
        setValid(isValid)

    }

    const onDataSubmit=(e)=>{
      const type = "";
      e.preventDefault();//prevent auto submit
      if(valid.error.firstname || !valid.firstname)
      {
          alert("no Valid fname");
      }
      else if(valid.error.lastname || !valid.lastname)
      {
          alert("no Valid lname");
      }
      else if(valid.error.email || !valid.email)
      {
          alert("no Valid email");
      }
      else if(valid.error.password || !valid.password)
      {
          alert("no Valid password");
      }
      else
      {
         
          const uservalue = valid;
          axios.post("https://api09.herokuapp.com/register",uservalue)
          .then((res)=>{
              const person=res.data;
              console.log(person);
          })
          .catch(err=>{
              console.log(err);
          })
      }
      
  }

    return(
        <>
        <Container style={backgroundstyle}>
        <Form onSubmit={onDataSubmit}>
        <Form.Group controlId="formBasicPassword">
        <Form.Label>First Name</Form.Label>
          <Form.Control name="firstname" id="fname" type="text" placeholder="First Name" onChange={handleChange}/>
          {valid.error.firstname.length > 0 && (<p style={p}>{valid.error.firstname}</p>)}
        </Form.Group>
        <Form.Group controlId="formBasicPassword">
        <Form.Label>Last Name</Form.Label>
          <Form.Control name="lastname" id="lname" type="text" placeholder="Last Name" onChange={handleChange}/>
          {valid.error.lastname.length > 0 && (<p style={p}>{valid.error.lastname}</p>)}
        </Form.Group>
        <Form.Group controlId="formGridAddress1">
         <Form.Label>Address</Form.Label>
        <Form.Control placeholder="1234 Main St" />
        </Form.Group>
        <Form.Row>
    <Form.Group as={Col} controlId="formGridCity">
      <Form.Label>City</Form.Label>
      <Form.Control />
    </Form.Group>

    <Form.Group as={Col} controlId="formGridState">
      <Form.Label>State</Form.Label>
      <Form.Control as="select" defaultValue="Choose...">
        <option>Choose...</option>
        <option>West Bengal</option>
      </Form.Control>
    </Form.Group>

    <Form.Group as={Col} controlId="formGridZip">
      <Form.Label>Pin Code</Form.Label>
      <Form.Control />
    </Form.Group>
  </Form.Row>
        <Form.Group controlId="exampleForm.ControlInput1">
        <Form.Label>Email Id</Form.Label>
          <Form.Control name="email" type="email" placeholder="Email" onChange={handleChange}/>
          {valid.error.email.length > 0 && (<p style={p}>{valid.error.email}</p>)}
        </Form.Group>
        <Form.Group controlId="exampleForm.ControlTextarea1">
        <Form.Label>Password</Form.Label>
          <Form.Control id="password" type="text" placeholder="password" name="password" onChange={handleChange}/>
          {valid.error.password.length > 0 && (<p style={p}>{valid.error.password}</p>)}
        </Form.Group>
        <Form.Group  controlId="formGridState">
      <Form.Label>Blood Group</Form.Label>
      <Form.Control as="select" defaultValue="Choose...">
      <option>Choose...</option>
        <option>A+</option>
        <option>A-</option>
        <option>B+</option>
        <option>B-</option>
        <option>O+</option>
        <option>O-</option>
        <option>AB+</option>
        <option>AB-</option>
      </Form.Control>
    </Form.Group>
        <fieldset>
    <Form.Group as={Row}>
      <Form.Label as="legend" column sm={2}>
        Gender
      </Form.Label>
      <Col sm={10}>
        <Form.Check
          type="radio"
          label="Male"
          name="formHorizontalRadios"
          id="formHorizontalRadios1"
        />
        <Form.Check
          type="radio"
          label="Female"
          name="formHorizontalRadios"
          id="formHorizontalRadios2"
        />
      </Col>
    </Form.Group>
  </fieldset>
  <Form.Group controlId="dob">
      <Form.Label>Date Of Birth</Form.Label>
      <Form.Control type="date" name="dob" placeholder="Date of Birth" />
      </Form.Group>
        <p style={{textAlign: "center"}}>
           <Button variant="danger" name="submit" type="submit">Submit</Button>
        </p>
        </Form>
        </Container>
        </>
    )
}

export default Register1;