import React from 'react'


export default function Data1(){
    
    return(
        <>
        
        <h1>data</h1>
        
        </>
    )
}