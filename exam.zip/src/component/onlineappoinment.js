import React from 'react'

export default function OnlineAppoinment1(){
    return(
        <>
        <h1>OnlineAppoinment</h1>
        </>
    )
}