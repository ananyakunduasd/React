import React from 'react'
import {Form,Button,Container} from 'react-bootstrap'


const Login1=()=>{

  const backgroundstyle={
    backgroundColor: "lightBlue",  
  padding: "10px",  
  fontFamily: "Arial" ,
  width:"450px",
  marginTop:"15px"
  }

     return(
         <>
         <Container style={backgroundstyle}>
  <Form>
  <Form.Group controlId="formBasicEmail">
    <Form.Label>Email address</Form.Label>
    <Form.Control name="email" type="email" placeholder="Enter email" />
  </Form.Group>
  <Form.Group controlId="formBasicPassword">
    <Form.Label>Password</Form.Label>
    <Form.Control name="password" type="password" placeholder="Password" />
  </Form.Group>
  <Form.Group controlId="formBasicCheckbox">
    <Form.Check name="checkbox" type="checkbox" label="Check me out" />
  </Form.Group>
 <Button variant="danger" name="submit" type="submit">
    Login
  </Button>
</Form>
</Container>
         </>
     )
}

export default Login1;