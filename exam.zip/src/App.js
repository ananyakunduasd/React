import logo from './logo.svg';
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import Router1 from './component/router';

function App() {
  return (
    <div>
     <Router1/>
    </div>
  );
}

export default App;
